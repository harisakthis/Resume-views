
import os
from flask import Flask, render_template, request, redirect, url_for, send_from_directory

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploaded_resumes'
app.config['RESUME_FILE'] = None  # Stores the latest uploaded resume file

# Create the upload directory if it doesn't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# In-memory database to store requests and view logs
access_requests = []
view_logs = []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/admin', methods=['GET', 'POST'])
def admin_dashboard():
    if request.method == 'POST':
        # Handle resume upload
        if 'resume' in request.files:
            resume = request.files['resume']
            if resume.filename != '':
                resume_path = os.path.join(app.config['UPLOAD_FOLDER'], resume.filename)
                resume.save(resume_path)
                app.config['RESUME_FILE'] = resume.filename
    return render_template('admin.html', requests=access_requests, view_logs=view_logs, resume_file=app.config['RESUME_FILE'])

@app.route('/resume')
def resume():
    if app.config['RESUME_FILE']:
        viewer_ip = request.remote_addr
        view_logs.append({'ip': viewer_ip})
        return send_from_directory(app.config['UPLOAD_FOLDER'], app.config['RESUME_FILE'])
    return "No resume uploaded yet.", 404

@app.route('/request-access', methods=['POST'])
def request_access():
    name = request.form.get('name')
    email = request.form.get('email')
    if name and email:
        access_requests.append({'name': name, 'email': email})
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
